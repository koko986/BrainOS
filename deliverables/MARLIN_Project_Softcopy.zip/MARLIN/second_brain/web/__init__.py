"""Local MARLIN web dashboard."""

