"""SQLite persistence layer."""

