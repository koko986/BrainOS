"""Symbolic reasoning services."""

