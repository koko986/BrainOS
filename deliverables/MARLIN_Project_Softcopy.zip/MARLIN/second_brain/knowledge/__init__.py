"""Knowledge graph services."""

